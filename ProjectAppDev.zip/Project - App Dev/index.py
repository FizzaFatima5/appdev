from dash import dcc,html
from dash.dependencies import Input,Output
from app import app
from EDA import data
from Apps import app1,app2

app.title="Car Maintenance Analytics Dashboard"

app.layout=html.Div([html.Link(
        rel='stylesheet',
        href='/Assets/style.css'  # This path should match where your CSS file is located
    ),
    html.H1(id="h1",children="WELCOME TO CAR MAINTENANCE ANALYTICS DASHBOARD",style={'textAlign':'center','color':'#FBEC5D','backgroundColor':'#702963','fontSize':'38px'}),
    
    html.H2(id="h2",children="This dashboard is based on real world dataset for a Car Maintenance Company.",style={'textAlign':'center','color':'black','backgroundColor': '#D8BFD8'}),
    html.Hr(style={'borderColor': '#702963', 'borderWidth': '5px', 'fontWeight': 'bold','color': '#702963', 'borderStyle': 'solid'}),
    html.Br(style={'color': '#D8BFD8'}),
    dcc.Location(id='url'),
    html.Div([dcc.Link("View Univariate Analysis",href='/Apps/app1',style={'margin-top': '20px','textAlign': 'center','color': '#FBEC5D','background-color': '#702963','border': '1px solid #702963','padding': '10px 15px','border-radius': '5px','display': 'inline-block','text-decoration': 'none'}),
    html.Br(style={'color': '#D8BFD8', 'margin-top': '10px'}),
    dcc.Link("View Bivariate Analysis",href='/Apps/app2',style={'margin-top': '20px','textAlign': 'center','color': '#FBEC5D','background-color': '#702963','border': '1px solid #702963','padding': '10px 15px','border-radius': '5px','display': 'inline-block','text-decoration': 'none'}),
    ],style={'textAlign': 'center', 'backgroundColor': '#D8BFD8'}),
    html.Div(id='page_content', children="This is the homepage. Please select the Analytical view you wish to see.", style={'textAlign': 'center', 'margin-top': '20px', 'backgroundColor': '#D8BFD8'})
])

@app.callback(Output('page_content','children'),
              Input('url','pathname'))

def display_page_content(path):
    if path == '/Apps/app1':
        return app1.layout
    elif path == '/Apps/app2':
        return app2.layout
    else:
        return "This is the homepage. Please select the Analytical view you wish to see."

if __name__=='__main__':
    app.run(debug=True)