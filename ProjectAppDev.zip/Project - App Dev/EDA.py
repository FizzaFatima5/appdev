import pandas as pd 
import numpy as np 

data=pd.read_csv('Dataset/Car_Maintenance_Data.csv')
print(data.shape)
print(data.columns)
print(data.head(10))
print(data.dtypes)
print(data.isnull().sum())
data['partList'] = data['partList'].fillna('parts not changed')
value_counts = data['partList'].value_counts()
print(value_counts)
print(data.isnull().sum())
data=data.dropna(subset=['Final Status'])
data=data.dropna()
print(data.isnull().sum())