from EDA import data
import pandas as pd
import numpy as np
from dash import dcc,html
from plotly import express as px
from dash.dependencies import Input,Output
from app import app

preventive_orders=data[data['vertical'] == 'PREVENTIVE']
non_preventive_orders=data[data['vertical'] == 'NON_PREVENTIVE']
diagnosis_orders=data[data['vertical'] == 'DIAGNOSIS']
car_spa_orders=data[data['vertical'] == 'CAR_SPA']
emergency_orders=data[data['vertical'] == 'EMERGENCY']
valet_orders=data[data['vertical'] == 'VALET']
rework_orders=data[data['vertical'] == 'REWORK']
parts_logistics_orders=data[data['vertical'] == 'PARTS_LOGISTICS']

layout=html.Div([
    html.H1("ORDER ANALYSIS ON VERTICAL LEVEL"),
    html.Br(),
    html.Label("SELECT THE VERTICAL", style={'fontWeight': 'bold'}),
    dcc.Dropdown(
        id='Vertical Dropdown',
        options=[
            {'label':'PREVENTIVE', 'value':'PREVENTIVE'},
            {'label':'NON_PREVENTIVE', 'value':'NON_PREVENTIVE'},
            {'label':'DIAGNOSIS', 'value':'DIAGNOSIS'},
            {'label':'CAR_SPA', 'value':'CAR_SPA'},
            {'label':'EMERGENCY', 'value':'EMERGENCY'},
            {'label':'VALET', 'value':'VALET'},
            {'label':'REWORK', 'value':'REWORK'},
            {'label':'PARTS_LOGISTICS', 'value':'PARTS_LOGISTICS'}
        ], value='PREVENTIVE'
    ),
    html.Br(),
    dcc.Graph(id='pie_chart')
])
@app.callback(
    Output('pie_chart','figure'),
    [Input('Vertical Dropdown','value')]
)
def update_pie_chart(selected_vertical):
    data_to_use = data[data['vertical']==selected_vertical]

    status_counts=data_to_use['Final Status'].value_counts()
    print(data_to_use)

    fig = px.pie(names=status_counts.index,values=status_counts.values, title=f'{selected_vertical} ORDERS', color_discrete_sequence=['#702963','#FDDA0D'])

    return fig