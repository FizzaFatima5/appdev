from EDA import data 
import pandas as pd
from plotly import express as px
from dash import dcc, html 
import numpy as np 

vertical_counts = data['vertical'].value_counts().reset_index()
vertical_counts.columns = ['Vertical', 'Count']

fig1 = px.bar(vertical_counts, x='Vertical', y='Count', title='Order Verticals', color='Vertical', color_discrete_map={'PREVENTIVE': '#702963', 'NON_PREVENTIVE': '#AA336A', 'CAR_SPA': '#FAFA33', 'DIAGNOSIS': '#FBEC5D', 'VALET': '#FDDA0D', 'REWORK': '#673147', 'EMERGENCY': '#800080', 'PARTS_LOGISTICS': '#FFC000'})


layout=html.Div([
    html.H1("VERTICAL ANALYSIS"),
    html.Br(),
    dcc.Graph(id='bar_plot', figure=fig1)
])